<template>
  <div class="app-container">

    <el-radio-group v-model="radio" @change="handleSingChoose">
      <el-radio-button :label="0">全部</el-radio-button>
      <el-radio-button :label="1">在线</el-radio-button>
      <el-radio-button :label="2">离线</el-radio-button>
    </el-radio-group>

    <el-tree
      ref="tree2"
      :data="allData"
      :props="defaultProps"
      class="filter-tree"
      @node-click="hanldeClickNode"
    />

  </div>
</template>

<script>
import lodash from 'lodash'
import treeData from '@/assets/data/tree.json'

function filterTree(tree) {
  const arr = lodash.cloneDeep(tree)
  const a = arr.map(item => {
    if (item.children) {
      item.children = item.children.filter(item0 => {
        if (item0.type !== '车载图传') {
          return true
        } else {
          if (item0.status !== 1) {
            return false
          } else {
            return true
          }
        }
      })
      filterTree(item.children)
    }
    return item
  })
  return a
}

export default {

  data() {
    return {
      allData: [],
      onData: [],
      offData: [],
      curData: [],
      defaultProps: {
        children: 'children',
        label: 'nodeName'
      },
      radio: 0
    }
  },
  created() {
    this.allData = treeData
    console.log('%c🌼(this.allData)🚭', 'font-size:20px;border:3px inset #42b983', this.allData)
  },
  computed: {},
  watch: {
    radio(v) {
      switch (v) {
        case 0:
          this.curData = this.allData
          break
        case 1:
          this.curData = this.onData
          break
        case 2:
          this.curData = this.offData
          break
      }
    }
  },

  methods: {
    handleSingChoose(e) {
      if (e === 1) { // 在线
        this.onData = filterTree(this.allData)
        console.log('%c🌼(this.onData)🚭', 'font-size:20px;border:3px inset #42b983', this.onData)
      } else if (e === 2) {
        this.offData = filterTree(this.allData)
      } else {
        this.curData = this.allData
      }
    },
    hanldeClickNode(e) {
      console.log('%c🌼(e)🚭', 'font-size:20px;border:3px inset #42b983', e)
    }
  }
}
</script>

